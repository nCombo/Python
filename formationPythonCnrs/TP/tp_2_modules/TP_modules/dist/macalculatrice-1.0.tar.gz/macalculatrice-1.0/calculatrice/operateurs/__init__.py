
import addition
import soustraction
import multiplication
import division

operations = {
    '+': addition.addition,
    '-': soustraction.soustraction,
    '*': multiplication.multiplication,
    '/': division.division
}

