# -*- coding: utf-8 -*-

def soustraction(a, b):
    """
    réalise la soustraction de deux nombres.

    :param a: premier nombre à soustraire
    :param b: deuxième nombre à soustraire
    :return: soustraction 

    """
    return a - b

