# -*- coding: utf-8 -*-

def addition(a, b):
    """
    réalise l'addition de deux nombres.

    :param a: premier nombre à additionner
    :param b: deuxième nombre à additionner
    :return: addition 

    """
    return a + b
