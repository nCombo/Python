# -*- coding: utf-8 -*-

def multiplication(a, b):
    """
    réalise la multiplication de deux nombres.

    :param a: premier nombre à multiplier
    :param b: deuxième nombre à multiplier
    :return: multiplication

    """
    return a*b

