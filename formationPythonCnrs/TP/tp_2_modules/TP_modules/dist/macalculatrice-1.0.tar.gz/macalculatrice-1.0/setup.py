from distutils.core import setup

setup(name = 'macalculatrice',
      version = '1.0',
      author = 'Nicolas CAN',
      description = 'module de calculatrice',
      packages = ['calculatrice', 'calculatrice.operateurs'],
  )